const stockPriceData = {
    '1': [65, 59, 80, 81, 56],
    '3': [70, 60, 90, 85, 75, 80],
    '6': [60, 70, 80, 90, 85, 95],
    '12': [55, 65, 75, 85, 95, 105]
};

const volumeData = {
    '1': [2000, 1500, 3000, 2500, 4000],
    '3': [2200, 1800, 3200, 2800, 3500],
    '6': [2100, 2400, 2900, 3100, 3300],
    '12': [2300, 2600, 3100, 3500]
};

const labels = ['January', 'February', 'March', 'April', 'May', 'June'];

let stockPriceChart = null;
let volumeChart = null;

function createCharts(timeframe) {
    const ctxStockPrice = document.getElementById('stockPriceChart').getContext('2d');
    const ctxVolume = document.getElementById('volumeChart').getContext('2d');

    if (stockPriceChart) {
        stockPriceChart.destroy();
        volumeChart.destroy();
    }

    stockPriceChart = new Chart(ctxStockPrice, {
        type: 'line',
        data: {
            labels: labels.slice(0, stockPriceData[timeframe].length),
            datasets: [{
                label: 'Stock Price',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 2,
                data: stockPriceData[timeframe],
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'top' },
                title: { display: true, text: 'Stock Price Over Time' }
            }
        }
    });

    volumeChart = new Chart(ctxVolume, {
        type: 'bar',
        data: {
            labels: labels.slice(0, volumeData[timeframe].length),
            datasets: [{
                label: 'Volume',
                backgroundColor: 'rgba(153, 102, 255, 0.2)',
                borderColor: 'rgba(153, 102, 255)',
                borderWidth: 2,
                data: volumeData[timeframe],
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'top' },
                title: { display: true, text: 'Trading Volume Over Time' }
            }
        }
    });
}

function updateCharts() {
    const timeframe = document.getElementById('timeframe').value;
    createCharts(timeframe);
}

// Initialize charts with default timeframe
createCharts('1');
